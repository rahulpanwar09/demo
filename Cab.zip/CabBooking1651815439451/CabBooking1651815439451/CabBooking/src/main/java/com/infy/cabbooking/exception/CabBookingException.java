package com.infy.cabbooking.exception;

public class CabBookingException extends Exception {

	private static final long serialVersionUID = 1L;
	
	public CabBookingException(String message) {
		super(message);
	}
}
