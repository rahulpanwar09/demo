package com.infy.cabbooking.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infy.cabbooking.dto.BookingDTO;
import com.infy.cabbooking.dto.CabDTO;
import com.infy.cabbooking.entity.Booking;
import com.infy.cabbooking.entity.Cab;
import com.infy.cabbooking.exception.CabBookingException;
import com.infy.cabbooking.repository.BookingRepository;
import com.infy.cabbooking.repository.CabRepository;
import com.infy.cabbooking.validator.BookingValidator;

@Service("cabBookingService")
@Transactional
public class CabBookingServiceImpl implements CabBookingService {

	@Autowired
	private BookingRepository bookingRepository;
	@Autowired
	private CabRepository cabRepository;


	@Override
	public List<BookingDTO> getDetailsByBookingType(String bookingType) throws CabBookingException {
		List<Booking> bookings = bookingRepository.findByBookingType(bookingType);
		if(bookings.isEmpty())
			throw new CabBookingException("Service.NO_DETAILS_FOUND.");
		
		List<BookingDTO> bookingDTO = new ArrayList<>();
			
		
		for(Booking booking : bookings) {
			BookingDTO bookingDTOs = new BookingDTO();
			bookingDTOs.setBookingId(booking.getBookingId());
			bookingDTOs.setCustomerName(booking.getCustomerName());
			bookingDTOs.setBookingType(booking.getBookingType());
			bookingDTOs.setPhoneNo(booking.getPhoneNo());
			Cab cabs = new Cab();
			CabDTO cabDTO = new CabDTO();
			cabDTO.setCabNo(cabDTO.getCabNo());
			cabDTO.setDriverPhoneNo(booking.getCab().getDriverPhoneNo());
			//cabDTO.setModelName();
			//cabDTO.setAvailability();
				
			bookingDTOs.setCabDTO(cabDTO);
				
			bookingDTO.add(bookingDTOs);
		}
		return bookingDTO;
		}


	
	@Override
	public Integer bookCab(BookingDTO bookingDTO) throws CabBookingException {
		
		BookingValidator bookingValidator = new BookingValidator();
		bookingValidator.validate(bookingDTO);
		Optional<Cab> optional = cabRepository.findById(bookingDTO.getCabDTO().getCabNo());
		Cab cab = optional.orElseThrow(()-> new CabBookingException("Service.CAB_NOT_FOUND"));
		if(cab.getAvailability()=="No")
	
			throw new CabBookingException("Service.CAB_NOT_AVAILABLE");
	
		
			Booking booking = new Booking();
			booking.setBookingId(bookingDTO.getBookingId());
			booking.setBookingType(bookingDTO.getBookingType());
			booking.setCustomerName(bookingDTO.getCustomerName());
			booking.setPhoneNo(bookingDTO.getPhoneNo());
			cab.setAvailability("No");
			Booking bookingEntity = bookingRepository.save(booking);
			return bookingEntity.getBookingId();
		}
		}
	





